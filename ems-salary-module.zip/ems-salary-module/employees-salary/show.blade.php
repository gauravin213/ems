@extends('employees-mgmt.base')

@section('action-content')
<div class="container">
    <h3>ssssssssssssssssss</h3>
   {{$id}}
</div>
@endsection
