@extends('employees-salary.base')
@section('action-content')
    <!-- Main content -->
    <section class="content">
      <div class="box">
  <div class="box-header">
    <div class="row">
        <div class="col-sm-8">
          <h3 class="box-title">List of salary</h3>
        </div>
        <div class="col-sm-4">
          <a class="btn btn-primary" href="{{ route('employee-salary.create') }}">Add new employee</a>
        </div>
    </div>
  </div>
  <!-- /.box-header -->
  <div class="box-body">
      <div class="row">
        <div class="col-sm-6"></div>
        <div class="col-sm-6"></div>
      </div>
    


    <form method="POST" action="{{ route('employee-salary.search') }}">

       {{ csrf_field() }}

          <div class="box box-default">
            <div class="box-header with-border">
              <h3 class="box-title">Search</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                  <div class="col-md-6">
                <div class="form-group">
                              <label for="inputemployeesid" class="col-sm-3 control-label">Employees</label>
                    <div class="col-sm-9">
                     <select class="form-control" name="employeesid">
                          <option value="-1">Please select employee</option>
                          @foreach ($employees as $employee)
                              <option value="{{$employee->id}}">{{$employee->lastname}} {{$employee->firstname}}</option>
                          @endforeach
                      </select>
                    </div>
                </div>
              </div>
              </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">
                <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                Search
              </button>
            </div>
          </div>      
    </form>



    <div id="example2_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
      <div class="row">
        <div class="col-sm-12">
          <table id="example2" class="table table-bordered table-hover dataTable" role="grid" aria-describedby="example2_info">
            <thead>
              <tr role="row">
               
                <th width="8%" class="sorting hidden-xs" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="HiredDate: activate to sort column ascending">Employee id</th>

                <th width="8%" class="sorting hidden-xs" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Department: activate to sort column ascending">Basic pay</th>

                <th width="8%" class="sorting hidden-xs" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Division: activate to sort column ascending">Increament</th>

                <th width="8%" class="sorting hidden-xs" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Division: activate to sort column ascending">Grad pay</th>

                <th width="8%" class="sorting hidden-xs" tabindex="0" aria-controls="example2" rowspan="1" colspan="1" aria-label="Division: activate to sort column ascending">Band</th>

                <th tabindex="0" aria-controls="example2" rowspan="1" colspan="2" aria-label="Action: activate to sort column ascending">Action</th>
              </tr>
            </thead>
            <tbody>
            @foreach ($employeeSalary as $empSalary)
                <tr role="row" class="odd">
                  <td class="hidden-xs">{{ $empSalary->employees_id }}</td>
                  <td class="hidden-xs">{{ $empSalary->cs_basic_salary }}</td>
                  <td class="hidden-xs">{{ $empSalary->cs_increament }}</td>
                  <td class="hidden-xs">{{ $empSalary->cs_grad_pay }}</td>
                  <td class="hidden-xs">{{ $empSalary->cs_band }}</td>
                  <td>
                    <form class="row" method="POST" action="{{ route('employee-salary.destroy', ['id' => $empSalary->id]) }}" onsubmit = "return confirm('Are you sure?')">
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <a href="{{ route('employee-salary.edit', ['id' => $empSalary->id]) }}" class="btn btn-warning col-sm-3 col-xs-5 btn-margin">
                        Update
                        </a>


                         <a href="{{ route('employee-salary.show',$empSalary->id) }}" class="btn btn-warning col-sm-3 col-xs-5 btn-margin">
                        View
                        </a>


                         <button type="submit" class="btn btn-danger col-sm-3 col-xs-5 btn-margin">
                          Delete
                        </button>
                    </form>
                  </td>
              </tr>
            @endforeach
            </tbody>
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-5">
          <div class="dataTables_info" id="example2_info" role="status" aria-live="polite">Showing 1 to {{count($employeeSalary)}} of {{count($employeeSalary)}} entries</div>
        </div>
        <div class="col-sm-7">
          <div class="dataTables_paginate paging_simple_numbers" id="example2_paginate">
            {{ $employeeSalary->links() }}
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /.box-body -->
</div>
    </section>
    <!-- /.content -->
  </div>
@endsection