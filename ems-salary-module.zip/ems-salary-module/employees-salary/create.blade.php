@extends('employees-salary.base')

@section('action-content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Add new employee</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ route('employee-salary.store') }}">
                        {{ csrf_field() }}


                        <!---->
                        <div class="form-group">
                            <label class="col-md-4 control-label">Employee</label>
                            <div class="col-md-6">
                                <select class="form-control" name="employees_id">
                                    <option value="-1">Please select employee</option>
                                    @foreach ($employees as $employee)
                                        <option value="{{$employee->id}}">{{$employee->lastname}} {{$employee->firstname}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('cs_basic_salary') ? ' has-error' : '' }}">
                            <label for="cs_basic_salary" class="col-md-4 control-label">Basic Pay</label>

                            <div class="col-md-6">
                                <input id="cs_basic_salary" type="text" class="form-control" name="cs_basic_salary" value="{{ old('cs_basic_salary') }}" required autofocus>

                                @if ($errors->has('cs_basic_salary'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('cs_basic_salary') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('cs_increament') ? ' has-error' : '' }}">
                            <label for="cs_increament" class="col-md-4 control-label">Increament</label>

                            <div class="col-md-6">
                                <input id="cs_increament" type="text" class="form-control" name="cs_increament" value="{{ old('cs_increament') }}" required autofocus>

                                @if ($errors->has('cs_increament'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('cs_increament') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('cs_grad_pay') ? ' has-error' : '' }}">
                            <label for="cs_grad_pay" class="col-md-4 control-label">Grade Pay</label>

                            <div class="col-md-6">
                                <input id="cs_grad_pay" type="text" class="form-control" name="cs_grad_pay" value="{{ old('cs_grad_pay') }}" required autofocus>

                                @if ($errors->has('cs_grad_pay'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('cs_grad_pay') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('cs_band') ? ' has-error' : '' }}">
                            <label for="cs_band" class="col-md-4 control-label">Band</label>

                            <div class="col-md-6">
                                <input id="cs_band" type="text" class="form-control" name="cs_band" value="{{ old('cs_band') }}" required autofocus>

                                @if ($errors->has('cs_band'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('cs_band') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                         <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Create
                                </button>
                            </div>
                        </div>
                        <!---->
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
