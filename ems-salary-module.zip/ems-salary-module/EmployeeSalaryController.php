<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use App\Employee;
use App\EmployeeSalary;
use App\City;
use App\State;
use App\Country;
use App\Department;
use App\Division;

class EmployeeSalaryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employeeSalary = DB::table('employee_salary')->paginate(5);

        $employees = Employee::all();

        return view('employees-salary/index', ['employeeSalary' => $employeeSalary, 'employees' => $employees]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $employees = Employee::all();
        return view('employees-salary/create', ['employees' => $employees]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validateInput($request);
       
        $keys = ['employees_id', 'cs_basic_salary', 'cs_increament', 'cs_grad_pay', 'cs_band'];
        $input = $this->createQueryInput($keys, $request);

       // print_r($input);
       
        EmployeeSalary::create($input);

        return redirect()->intended('/employee-salary');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return view('employees-salary/show', ['id' => $id]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employees = Employee::all();
        $employeeSalary = EmployeeSalary::find($id);
        return view('employees-salary/edit', ['employeeSalary' => $employeeSalary, 'employees'=>$employees]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $employee = EmployeeSalary::findOrFail($id);
        $this->validateInput($request);
        $keys = ['employees_id', 'cs_basic_salary', 'cs_increament', 'cs_grad_pay', 'cs_band'];
        $input = $this->createQueryInput($keys, $request);

        EmployeeSalary::where('id', $id)
            ->update($input);

        return redirect()->intended('/employee-salary');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         EmployeeSalary::where('id', $id)->delete();
         return redirect()->intended('/employee-salary');
    }

    /**
     * Search state from database base on some specific constraints
     *
     * @param  \Illuminate\Http\Request  $request
     *  @return \Illuminate\Http\Response
     */
    public function search(Request $request) {
        $constraints = [
            'employeesid' => $request['employeesid'],
            ];

        $employeeSalary = $this->doSearchingQuery($constraints);

         $employees = Employee::all();
        
        return view('employees-salary/index', ['employees' => $employees, 'employeeSalary' => $employeeSalary, 'searchingVals' => $constraints]);
    }

    private function doSearchingQuery($constraints) {
        $query = DB::table('employee_salary')->where('employees_id', '=', $constraints['employeesid'] )->paginate(5);
        return $query;
    }

     /**
     * Load image resource.
     *
     * @param  string  $name
     * @return \Illuminate\Http\Response
     */
    public function load($name) {
         $path = storage_path().'/app/avatars/'.$name;
        if (file_exists($path)) {
            return Response::download($path);
        }
    }

    private function validateInput($request) {
        $this->validate($request, [
            'cs_basic_salary'  => 'required',
            'cs_increament'  => 'required',
            'cs_grad_pay'  => 'required',
            'cs_band'  => 'required'
        ]);
    }

    private function createQueryInput($keys, $request) {
        $queryInput = [];
        for($i = 0; $i < sizeof($keys); $i++) {
            $key = $keys[$i];
            $queryInput[$key] = $request[$key];
        }

        return $queryInput;
    }



    public function emp_manag_view_rep(Request $request)
    {
        
        return view('employees-salary/view');
       //die('@@');
    }


}
