@extends('employees-mgmt.base')

@section('action-content')
<div class="container">
    <h3>VVVVVVVVVVVV</h3>
</div>
@endsection
