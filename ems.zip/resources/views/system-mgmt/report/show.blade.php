@extends('employees-mgmt.base')

@section('action-content')
<div class="container">


	<div class="col-sm-4">
            <form class="form-horizontal" role="form" method="POST" action="{{ route('report.pdf') }}">
                {{ csrf_field() }}
                <input type="hidden" value="2019/08/20" name="from">
                <input type="hidden" value="2019/09/19" name="to">
                <input type="hidden" value="{{$id}}" name="emp_id">
                <button type="submit" class="btn btn-info">
                  Export to PDF
                </button>
            </form>
        </div>
    <h3>ssssssssssssssssss</h3>
 	{{$id}}
</div>
@endsection
